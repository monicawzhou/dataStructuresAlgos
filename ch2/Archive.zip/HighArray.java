package ch2;

public class HighArray {

	private long[] a; // ref to array a
	private int nElems; // number of data items

	public HighArray(int max) // constructor
	{
		a = new long[max]; // create the array
		nElems = 0; // no items yet
	}

	public long[] noDups() {
		long compare;
		int nullCount=0;
		for(int j=0;j<a.length;j++) {
			compare = a[j];
			
		
			for(int i=0;i<a.length-1;i++) {
				if(i==j) {
					i++;
				}
				if(compare==a[i]) {
					a[i] = -1;
					
				}
			}
		}
		for(int i=0;i<a.length;i++) {
			System.out.println("a[i]: "+a[i]);
		}



		for(int k=0;k<a.length;k++) {
			if(a[k]==-1) {
				nullCount++;
			}
		}

		for(int k=0;k<a.length;k++) {
			if(a[k]==-1){
				for(int m = k; m<a.length-1;m++) {
					a[m] = a[m+1];
				}
			}
		} 

		
		System.out.println("nullcount: "+nullCount);
		int arrSize = a.length - nullCount;
		System.out.println("arrSize: "+arrSize);
		long[] noDupArr = new long[arrSize];
		for(int n=0;n<arrSize;n++) {
			noDupArr[n] = a[n];
			System.out.println("noDup: "+noDupArr[n]);
			System.out.println("an: "+a[n]);
		}
		
		return noDupArr;
	}

	public long getMax() {
		long maxValue=0;
		if (nElems == 0) {
			return -1;
		} else {
			for(int i=0;i<nElems;i++)
			{
				if(a[i]>maxValue) {
					maxValue = a[i];
				}
			}
			return maxValue;
		}
	}
	
	public void removeMax() {
		long maxValue = getMax();
		int index=0;
		// find index maxValue
		for(int i=0;i<nElems;i++) {
			if(a[i] == maxValue) {
				index = i;
				break;
			}
		}
		
		//delete maxValue
		for(int k=index;k<nElems;k++){
			a[k] = a[k+1];
		}
		nElems--;
	}
	
	public int getSize() {
		return nElems;
	}


	public boolean find(long searchKey)
	{ // find specified value
		int j;
		for(j=0; j<nElems; j++) // for each element,
			if(a[j] == searchKey) // found item?
				break; // exit loop before end
		if(j == nElems) // gone to end?
			return false; // yes, can’t find it
		else
			return true; // no, found it
	} // end find()

	public void insert(long value) // put element into array
	{
		a[nElems] = value; // insert it
		nElems++; // increment size
	}

	public boolean delete(long value)
	{
		int j;
		for(j=0; j<nElems; j++) // look for it
			if( value == a[j] )
				break;
		if(j==nElems) // can’t find it
			return false;
		else // found it
		{
			for(int k=j; k<nElems; k++) // move higher ones down
				a[k] = a[k+1];
			nElems--; // decrement size
			return true;
		}
	} // end delete()

	public void display() // displays array contents
	{
		for(int j=0; j<nElems; j++) // for each element,
			System.out.print(a[j] + " "); // display it
		System.out.println("");
	}
}
