package ch2;

class OrdArray
{
	private long[] a; // ref to array a
	private int nElems; // number of data items
	 
	public OrdArray(int max) // constructor
	{
		a = new long[max]; // create array
		nElems = 0;
	}
	 
	public int size()
	{ return nElems; }
	 
	public int find(long searchKey)
	{
		int lowerBound = 0;
		int upperBound = nElems-1;
		int curIn;
		while(true)
		{
			curIn = (lowerBound + upperBound ) / 2;
			if(a[curIn]==searchKey)
				return curIn; // found it
			else if(lowerBound > upperBound)
				return nElems; // can’t find it
			else // divide range
			{
				if(a[curIn] < searchKey)
					lowerBound = curIn + 1; // it’s in upper half
				else
					upperBound = curIn - 1; // it’s in lower half
			} // end else divide range
		} // end while
	} // end find()
	 

	public int insertBinary(long searchKey) // put element into array
	{
		int lowerBound = 0;
		int upperBound = nElems-1;
		int curIn;
		while(true)
		{
			curIn = (lowerBound + upperBound ) / 2;
			if(a[curIn]==searchKey)
				return curIn; // found it
			
			else // divide range
			{
				if(a[curIn] < searchKey) {
					lowerBound = curIn + 1; // it’s in upper half
					if(lowerBound>upperBound) {
						return curIn+1;
					}
				}
				
				else {
					upperBound = curIn - 1; // it’s in lower half
					if(lowerBound>upperBound) {
						return curIn;
					}
				}
			} // end else divide range
		}
	}
			
	public void insert(long value) {
		if(nElems==0) {
			a[nElems] = value;
		}
		
		int j = insertBinary(value);
		
		for(int k=nElems; k>j; k--) // move bigger ones up
			a[k] = a[k-1];
		a[j] = value; // insert it
		nElems++; // increment size
	} 
	
	public long[] merge(OrdArray b) {
		int insert=0;
		int bLength = b.size();
		long[] merged = new long[a.length+bLength];
		int aIn=0;
		int bIn=0;
		

		while(aIn<a.length && bIn<bLength ) {
			if(a[aIn] < b.a[bIn]) {
				merged[insert] = a[aIn];
				aIn++;
			} else if (a[aIn] > b.a[bIn]) {
				merged[insert] = b.a[bIn];
				bIn++;
			} else {
				merged[insert] = a[aIn];
				aIn++;
			}
			insert++;
		}
		
		while(aIn<a.length) {
			merged[insert] = a[aIn];
			insert++;
			aIn++;
		}
		
		while(bIn<bLength) {
			merged[insert] = b.a[bIn];
			insert++;
			bIn++;
		}
		
		
//		int aCounter=0;
//		int bCounter=0;
//		long[] merged = new long[100];
//		for(int i=0;i<a.length;i++) {
//			
//			for(int j=0;j<bLength;j++) {
//				if(a[i]<b.a[j]) {
//					merged[insert] = a[i];
//					insert++;
//					i++;
//					aCounter++;
//					j--;
//					
//				} else if (a[i]>b.a[j]) {
//					merged[insert] = b.a[j];
//					insert++;
//					j++;
//					bCounter++;
//					
//				} else {
//					merged[insert] = b.a[j];
//					insert++;
//					j++;
//					bCounter++;
//					
//				}
//			}
//		}
//		System.out.println("bCounter: "+bCounter);
//		System.out.println("aCounter: "+aCounter);
//		
//		if(bCounter<bLength) {
//			for(int k = bCounter;k<bLength;k++) {
//				merged[insert] = b.a[k];
//				insert++;
//			}
//		}
//		
//		if(aCounter<a.length) {
//			for(int m = aCounter;m<a.length;m++) {
//				merged[insert] = a[m];
//				insert++;
//			}
//		}
		
		return merged;
	}

	 
	public boolean delete(long value)
	{
		int j = find(value);
		if(j==nElems) // can’t find it
			return false;
		else // found it
		{
			for(int k=j; k<nElems; k++) // move bigger ones down
				a[k] = a[k+1];
			nElems--; // decrement size
			return true;
		}
	} // end delete()
	 
	public void display() // displays array contents
	{
		for(int j=0; j<nElems; j++) // for each element,
			System.out.print(a[j] + " "); // display it
		System.out.println("");
	}
	 
} // end class OrdArray