package ch2;

public class HighArrayApp {
	public static void main(String[] args) {

		int maxSize = 100; // array size
		HighArray arr; // reference to array
		arr = new HighArray(maxSize); // create the array
		arr.insert(77); // insert 10 items
		arr.insert(99);
		arr.insert(44);
		arr.insert(55);
		arr.insert(22);
		arr.insert(88);
		arr.insert(11);
		arr.insert(00);
		arr.insert(66);
		arr.insert(33);
		arr.display(); // display items
		int searchKey = 35; // search for item
		if( arr.find(searchKey) )
			System.out.println("Found " + searchKey);
		else
			System.out.println("Can’t find " + searchKey);
		arr.delete(00); // delete 3 items
		arr.delete(55);
		arr.delete(99);
		arr.display(); // display items again
		
		
		long maxValue = arr.getMax();
		System.out.println("maxValue: "+maxValue);
		arr.removeMax();
		
		arr.display();
		int arrSize = arr.getSize();
		System.out.println("arrSize: "+arrSize);
		HighArray sortedArr = new HighArray(arrSize);
		
		for(int i=0;i<arrSize;i++) {
			long maxToInsert = arr.getMax();
			sortedArr.insert(maxToInsert);
			arr.removeMax();
		}
		sortedArr.display();
		
		
		HighArray dups = new HighArray(5);
		dups.insert(2);
		dups.insert(2);
		dups.insert(3);
		dups.insert(4);
		dups.insert(4);
		
		dups.display();
		
		long[] noDups = dups.noDups();
		
		for (int i=0;i<noDups.length;i++) {
			System.out.println(noDups[i]);
		}
		
		
		
	} // end main()
	// end class HighArrayApp
}
